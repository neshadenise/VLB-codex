## Goal

After a user uploads a self-reference photo (currently the "Use My Photo" flow), show a post-upload dialog asking whether to also (a) extract the visible outfit into Closet items, and/or (b) save a polished full-look render to the Lookbook. Both are opt-in, can be combined, and respect existing per-user RLS.

## UX flow

Today: pick file → click "Use This Photo ✦" → `normalizeUploadedModel` runs → model saved → navigate to Studio.

New:
1. Same upload + normalize step runs and the Model is saved (unchanged — this is the user's reusable base photo with identity preserved).
2. Before navigating to Studio, open a new `PostUploadSavingsDialog` with:
   - Checkbox: **Add outfit items to Closet** (default off)
   - Checkbox: **Add full look to Lookbook** (default off)
   - Buttons: `Skip`, `Save selected`
3. On `Save selected`:
   - If Closet checked → run garment detection on the original uploaded photo, create one `closet_items` row per detected piece.
   - If Lookbook checked → run full-look render, save one `looks` row tied to the new model.
   - Show per-section progress + toasts; failures in one section don't block the other.
4. On `Skip` or after save completes → navigate to Studio as today.

The dialog appears immediately after upload analysis (i.e. right after `normalizeUploadedModel` resolves and the model is persisted). Cancelling = just navigates on without saving extras.

## Server functions (new, in `src/lib/ai.functions.ts`)

Both use `requireSupabaseAuth` and `withCredit` like the existing fns.

1. `detectOutfitItems({ imageUrl })`
   - Step 1: text call to `GATEWAY` with the photo + system prompt: "List each distinct visible garment/accessory worn by the subject. For each return `{ name, category (from ALLOWED_CATEGORIES), subcategory, color, brand, gender, season[], tags[], crop_hint }`. Respond as JSON `{ items: [...] }`." Reuses the existing `ALLOWED_CATEGORIES` whitelist and validation logic from `analyzeGarment`.
   - Step 2: for each detected item, call `openaiEdit` with a prompt like "Isolate ONLY the {name} ({crop_hint}) from this photo. Place it flat on a clean pure-white studio background, product-shot style, no person, no other garments, preserve original color, fabric, and print exactly." Returns `dataUrl` per item.
   - Returns `{ items: [{ ...meta, dataUrl }], error? }`. Charges 1 credit per isolation call (so the cost scales with the number of garments — surface that in the dialog copy).

2. `renderFullLook({ imageUrl, pose?, accessibilityFlags?, note? })`
   - Wraps `openaiEdit` with a prompt that says: "Re-photograph this person wearing the SAME outfit they have on, on the same neutral studio backdrop used for our editorial base photos. Preserve every garment exactly (color, cut, print, layering, footwear, accessories). Preserve face, body shape, skin tone, hair, glasses, tattoos, mobility aids, prosthetics, limb differences, seated posture if applicable." Includes the existing `IDENTITY`, `SKIN_BLEND`, and (when applicable) `ACCESSIBILITY` blocks plus pose handling identical to `normalizeUploadedModel`.
   - Returns `{ dataUrl, error? }`. 1 credit.

Both fns input-validate with Zod (URL + optional short strings + bounded a11y flag array), mirror the shape of existing fns.

## Client changes (`src/routes/_authenticated/models.tsx`)

- Extract the post-normalize work into a new component `PostUploadSavingsDialog` rendered alongside `CreateModelDialog`. It receives `{ open, onOpenChange, rawPhotoUrl, normalizedModel, pose, accessibilityFlags, onDone }`.
- In `CreateModelDialog.submit` (upload branch):
  - After `addModel` succeeds, instead of `toast.success` + immediate `nav(...)`, stash `{ model, rawPhotoUrl, pose, accessibilityFlags }` in component state and open the new dialog. Close the create dialog.
  - `onDone` (from the savings dialog) is what navigates to Studio.
- `PostUploadSavingsDialog`:
  - Two checkbox rows with short descriptions + a credits hint ("≈1 credit + 1 per detected item" / "≈1 credit").
  - `Skip` → `onDone(model.id)`.
  - `Save selected`:
    1. If Closet: call `detectOutfitItems({ data: { imageUrl: rawPhotoUrl } })`. For each returned item with no error, `uploadDataUrl(item.dataUrl, "closet")` then `addItem({ name, category, subcategory, imageUrl, color, brand, gender, season, tags, source: "self-photo" })`. Existing `addItem` already enforces `auth.uid()` via insert + RLS; subcategory string flows through unchanged (auto-creation of new subcategory rows mirrors the existing closet add flow — call `addSubcategory(category, subcategory)` first if the value isn't in `subcategories`).
    2. If Lookbook: call `renderFullLook({ data: { imageUrl: rawPhotoUrl, pose, accessibilityFlags } })`, `uploadDataUrl(dataUrl, "looks")`, then `saveLook({ name: model.name + " — full look", modelId: model.id, imageUrl, itemIds: [] })`.
    3. Show toasts: `Added N items to your Closet ✦`, `Saved full look to your Lookbook ✦`, and a single error toast per failed branch.
    4. Always call `onDone(model.id)` at the end, even on partial failure.
- Use `useStudio()` to access `addItem`, `addSubcategory`, `saveLook`, `subcategories`. Use existing `uploadDataUrl` from `@/lib/storage`.

## Privacy / RLS

No schema changes. `closet_items`, `closet_subcategories`, and `looks` all already enforce `auth.uid() = user_id` on select/insert/update/delete. New rows are created through the existing `addItem` / `addSubcategory` / `saveLook` helpers in `useStudio`, which set `user_id = requireUser()`. No admin client, no cross-user data exposure.

## Out of scope

- No changes to credit pricing logic beyond reusing `withCredit`.
- No changes to Studio, Lookbook page, or Closet page UI.
- No background job / queue — operations run inline with a spinner.
- No edits to the AI-generated model flow (the dialog only triggers in the upload branch).

## Verification

- `bunx tsc --noEmit` clean.
- Manual: upload a full-body photo with a recognizable outfit, choose (none / closet only / lookbook only / both). Confirm rows appear in Closet and Lookbook, scoped to the signed-in user, and the Studio nav still happens after the dialog closes.