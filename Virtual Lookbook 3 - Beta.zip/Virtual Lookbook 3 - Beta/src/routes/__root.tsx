import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { SpeedInsights } from "@vercel/speed-insights/react";

import appCss from "../styles.css?url";
import { StudioProvider } from "@/lib/store";
import { Toaster } from "@/components/ui/sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md text-center glass rounded-3xl p-10 shadow-soft">
        <div className="font-display text-7xl text-gradient">404</div>
        <h2 className="mt-4 text-xl font-display">This page slipped off the moodboard</h2>
        <p className="mt-2 text-sm text-muted-foreground">Let's get you back to the studio.</p>
        <div className="mt-6">
          <Link to="/" className="inline-flex items-center justify-center rounded-full bg-glow px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-glow">
            Back to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md text-center glass rounded-3xl p-10">
        <h1 className="font-display text-2xl">A seam came undone</h1>
        <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button onClick={() => { router.invalidate(); reset(); }} className="rounded-full bg-glow px-5 py-2 text-sm text-primary-foreground shadow-glow">Try again</button>
          <a href="/" className="rounded-full glass px-5 py-2 text-sm">Home</a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Virtual Lookbook — AI fashion styling & moodboards" },
      { name: "description", content: "Upload outfits, style AI fashion models, build lookbooks and moodboards in a pastel goth or dark astrology studio." },
      { property: "og:title", content: "Virtual Lookbook — AI fashion styling & moodboards" },
      { property: "og:description", content: "Upload outfits, style AI fashion models, build lookbooks and moodboards in a pastel goth or dark astrology studio." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "Virtual Lookbook" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Virtual Lookbook — AI fashion styling & moodboards" },
      { name: "twitter:description", content: "Upload outfits, style AI fashion models, build lookbooks and moodboards in a pastel goth or dark astrology studio." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/6FRSxk5WEsYlmTbkqPzdIWdSOFk2/social-images/social-1778953064050-78D24344-B10C-4D2A-905F-E0E878C49D99.webp" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/6FRSxk5WEsYlmTbkqPzdIWdSOFk2/social-images/social-1778953064050-78D24344-B10C-4D2A-905F-E0E878C49D99.webp" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Barlow+Condensed:wght@500;600;700;800&family=Inter:wght@400;500;600&display=swap",
      },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "Organization",
              "@id": "https://virtuallookbookpro.lovable.app/#organization",
              name: "Virtual Lookbook",
              url: "https://virtuallookbookpro.lovable.app",
              logo: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/61ec0db8-eae2-48e0-932b-a4dff1d73562",
              sameAs: ["https://www.instagram.com/wrestlegirlnesh"],
            },
            {
              "@type": "WebSite",
              "@id": "https://virtuallookbookpro.lovable.app/#website",
              name: "Virtual Lookbook",
              url: "https://virtuallookbookpro.lovable.app",
              description: "AI fashion styling studio — generate models, dress them with your real clothes, save looks and moodboards.",
              publisher: { "@id": "https://virtuallookbookpro.lovable.app/#organization" },
              inLanguage: "en",
            },
            {
              "@type": "SoftwareApplication",
              name: "Virtual Lookbook",
              applicationCategory: "DesignApplication",
              operatingSystem: "Web",
              description: "AI-powered virtual try-on studio for fashion lovers — upload clothes, generate inclusive fashion models, and style outfits with generative AI.",
              offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
            },
          ],
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <StudioProvider>
        <Outlet />
        <Toaster />
        <SpeedInsights />
      </StudioProvider>
    </QueryClientProvider>
  );
}
