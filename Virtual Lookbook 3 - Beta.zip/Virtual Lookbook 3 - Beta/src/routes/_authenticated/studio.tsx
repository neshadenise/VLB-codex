import { createFileRoute, useSearch, Link } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { useStudio, ClosetItem, Model } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sparkles, Undo2, RotateCcw, Save, Plus, Loader2, Check, X, Shirt, Trash, Layers } from "lucide-react";
import { useState, useMemo, useEffect, useRef } from "react";
import { toast } from "sonner";
import { applyGarment, restyleLook } from "@/lib/ai.functions";
import { uploadDataUrl } from "@/lib/storage";
import { cn } from "@/lib/utils";
import { requireSignIn } from "@/lib/require-auth";

export const Route = createFileRoute("/_authenticated/studio")({
  head: () => ({
    meta: [
      { title: "Styling Studio · Virtual Lookbook" },
      { name: "description", content: "AI styling studio — dress your model with garments from your closet, restyle with a sentence, and save the result as a new look." },
      { property: "og:title", content: "Styling Studio · Virtual Lookbook" },
      { property: "og:description", content: "AI try-on studio. Style your model and save looks without overwriting the base template." },
      { property: "og:url", content: "https://virtuallookbookpro.lovable.app/studio" },
    ],
    links: [{ rel: "canonical", href: "https://virtuallookbookpro.lovable.app/studio" }],
  }),
  validateSearch: (s: Record<string, unknown>) => ({
    model: (s.model as string) || undefined,
    look: (s.look as string) || undefined,
  }),
  component: StudioPage,
});

const STYLE_CHIPS = [
  "let the open shirt hang off the shoulders",
  "tuck the top into the waistband",
  "roll up the sleeves",
  "untie and loosen the laces",
  "pop the collar",
  "knot the hem at the waist",
  "drape the jacket over one shoulder",
];

const POSE_CHIPS = [
  "runway pose", "walking pose", "hands on hips", "editorial pose",
  "over-the-shoulder", "leaning pose", "sitting pose",
];

const INFANT_POSE_CHIPS = [
  "top-down on a soft blanket",
  "side-lying on a quilted blanket",
  "sitting up on a plush rug",
  "tummy time on a knit quilt",
  "swaddled flat-lay",
];

function StudioPage() {
  const {
    models, items, looks, activeClosetId, saveLook,
    studioTray, addToTray, removeFromTray, clearTray,
    studioSession, setStudioSession, resetStudioSession,
    user,
  } = useStudio();
  const search = useSearch({ from: "/_authenticated/studio" });
  const modelId = studioSession.modelId || search.model || models[0]?.id;
  const setPickedId = (id: string) => setStudioSession({ modelId: id });
  const model = useMemo(() => models.find((m: Model) => m.id === modelId), [models, modelId]);

  // Persisted working session — never mutates the model template in DB.
  const sessionImage = studioSession.image;
  const sessionHistory = studioSession.history;
  const sessionWornIds = studioSession.wornIds;
  const sessionLookId = studioSession.lookId;
  const setSessionImage = (v: string) => setStudioSession({ image: v });
  const setSessionHistory = (updater: string[] | ((h: string[]) => string[])) =>
    setStudioSession({ history: typeof updater === "function" ? (updater as any)(studioSession.history) : updater });
  const setSessionWornIds = (updater: string[] | ((w: string[]) => string[])) =>
    setStudioSession({ wornIds: typeof updater === "function" ? (updater as any)(studioSession.wornIds) : updater });
  const setSessionLookId = (v: string | null) => setStudioSession({ lookId: v });
  const initedFor = useRef<string>("");
  const generatingRef = useRef(false);

  // Initialize session when model changes or a "look" search param is present.
  // Only runs if there's no persisted image for this model yet, so navigating
  // back to the studio preserves the previous render.
  useEffect(() => {
    if (!model) return;
    const key = `${model.id}|${search.look || ""}`;
    if (initedFor.current === key) return;
    initedFor.current = key;
    // If session already matches this model and has content, keep it.
    if (
      studioSession.modelId === model.id &&
      !search.look &&
      studioSession.image
    ) {
      return;
    }
    if (search.look) {
      const look = looks.find((l) => l.id === search.look);
      if (look) {
        setStudioSession({
          modelId: model.id,
          image: look.imageUrl,
          history: [],
          wornIds: look.itemIds,
          lookId: look.id,
        });
        // Pre-fill tray with the look's items so user can keep editing them.
        addToTray(look.itemIds);
        return;
      }
    }
    setStudioSession({
      modelId: model.id,
      image: model.baseImageUrl,
      history: [],
      wornIds: [],
      lookId: null,
    });
  }, [model, search.look, looks, addToTray, studioSession.modelId, studioSession.image, setStudioSession]);

  const [busy, setBusy] = useState(false);
  const styleInput = studioSession.styleInput;
  const setStyleInput = (v: string) => setStudioSession({ styleInput: v });
  const multiSelect = studioSession.multiSelect;
  const setMultiSelect = (v: boolean | ((p: boolean) => boolean)) =>
    setStudioSession({ multiSelect: typeof v === "function" ? (v as any)(studioSession.multiSelect) : v });
  const selectedTrayIds = studioSession.selectedTrayIds;
  const setSelectedTrayIds = (v: string[] | ((p: string[]) => string[])) =>
    setStudioSession({ selectedTrayIds: typeof v === "function" ? (v as any)(studioSession.selectedTrayIds) : v });

  // Tray + closet strip scoped to the active closet.
  const closetItems = useMemo(
    () => items.filter((it) => !activeClosetId || (it.closetId || null) === activeClosetId),
    [items, activeClosetId],
  );
  const trayItems = useMemo(
    () => studioTray
      .map((id) => closetItems.find((i) => i.id === id))
      .filter(Boolean) as ClosetItem[],
    [studioTray, closetItems],
  );
  // Items still hanging in the closet = not currently in the tray.
  const closetStripItems = useMemo(
    () => closetItems.filter((it) => !studioTray.includes(it.id)),
    [closetItems, studioTray],
  );

  if (!model) {
    return (
      <AppLayout>
        <div className="glass rounded-3xl p-12 text-center max-w-xl mx-auto mt-10">
          <Sparkles className="h-10 w-10 mx-auto mb-3 text-primary" />
          <div className="font-display text-3xl">No model loaded</div>
          <p className="text-muted-foreground text-sm mt-2 mb-6">Generate a model to begin styling.</p>
          <Link to="/models"><Button className="rounded-full bg-glow text-primary-foreground shadow-glow"><Plus className="h-4 w-4 mr-1" /> Create Your First Model</Button></Link>
        </div>
      </AppLayout>
    );
  }

  const applyOne = async (item: ClosetItem) => {
    if (!requireSignIn(user, "try on garments")) return;
    if (generatingRef.current) { toast.message("Generating… please wait"); return; }
    generatingRef.current = true;
    setBusy(true);
    const baseUrl = sessionImage;
    try {
      toast.message(`Applying ${item.name}…`);
      const res: any = await applyGarment({ data: {
        baseImageUrl: baseUrl,
        garmentImageUrl: item.imageUrl,
        garmentName: item.name,
        garmentCategory: item.category,
        garmentSubcategory: item.subcategory,
        modelPrompt: model!.prompt,
        modelPose: model!.pose,
        isInfant: !!model!.isInfant,
        isChild: !!model!.isChild,
      }});
      if (res.error || !res.dataUrl) { toast.error(res.error || `Try-on failed: ${item.name}`, { duration: 6000 }); return; }
      const url = await uploadDataUrl(res.dataUrl, "looks");
      setSessionHistory((h) => [...h, baseUrl]);
      setSessionImage(url);
      setSessionWornIds((w) => w.includes(item.id) ? w : [...w, item.id]);
      toast.success(`${item.name} applied ✦`);
    } catch (e: any) { toast.error(e?.message || "Failed"); }
    finally { generatingRef.current = false; setBusy(false); }
  };

  const toggleTraySelection = (id: string) => {
    setSelectedTrayIds((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id]);
  };

  const styleAllSelected = async () => {
    const picks = trayItems.filter((it) => selectedTrayIds.includes(it.id));
    if (picks.length === 0) { toast.message("Select items in the tray first"); return; }
    if (!requireSignIn(user, "style multiple items")) return;
    if (generatingRef.current) { toast.message("Generating… please wait"); return; }
    const list = picks.map((it) => `${it.name}${it.category ? ` (${it.category})` : ""}`).join(", ");
    const instruction = `Dress the model in this complete outfit at once: ${list}. Layer items realistically by category, replacing any conflicting garments. Keep the model's identity, framing, lighting, and background unchanged. Editorial fashion photography.`;
    await restyle(instruction);
    setSessionWornIds((w) => Array.from(new Set([...w, ...picks.map((p) => p.id)])));
    setSelectedTrayIds([]);
  };

  // Click closet item → send to tray (no generation). Click in tray → generate.
  const sendToTray = (item: ClosetItem) => {
    if (!studioTray.includes(item.id)) addToTray(item.id);
  };

  const restyle = async (instruction: string) => {
    if (!instruction.trim()) return;
    if (!requireSignIn(user, "restyle")) return;
    if (generatingRef.current) { toast.message("Generating… please wait"); return; }
    generatingRef.current = true;
    setBusy(true);
    try {
      const res: any = await restyleLook({ data: { baseImageUrl: sessionImage, instruction } });
      if (res.error || !res.dataUrl) { toast.error(res.error || "Restyle failed", { duration: 6000 }); return; }
      const url = await uploadDataUrl(res.dataUrl, "looks");
      setSessionHistory((h) => [...h, sessionImage]);
      setSessionImage(url);
      toast.success("Restyled ✦");
      setStyleInput("");
    } catch (e: any) { console.error(e); toast.error(e?.message || "Failed"); }
    finally { generatingRef.current = false; setBusy(false); }
  };

  const applyPose = (pose: string) =>
    restyle(`Change the model's pose to a ${pose}. Keep the outfit, framing, identity, lighting, and background unchanged.`);

  const undo = () => {
    setSessionHistory((h) => {
      if (h.length === 0) return h;
      const prev = h[h.length - 1];
      setSessionImage(prev);
      return h.slice(0, -1);
    });
  };
  const revertTo = (idx: number) => {
    if (idx < 0 || idx >= sessionHistory.length) return;
    const target = sessionHistory[idx];
    setSessionImage(target);
    setSessionHistory((h) => h.slice(0, idx));
  };
  const resetSession = () => {
    resetStudioSession();
    setStudioSession({ modelId: model.id, image: model.baseImageUrl });
  };

  const save = async () => {
    if (sessionImage === model.baseImageUrl) {
      toast.message("Style something first");
      return;
    }
    const baseName = sessionLookId ? `${model.name} edit` : `${model.name} look`;
    const saved = await saveLook({ name: baseName, modelId: model.id, imageUrl: sessionImage, itemIds: sessionWornIds });
    if (saved) {
      setSessionLookId(saved.id);
      toast.success("Saved as a new look ✦ (your model template stays bare)");
    }
  };

  return (
    <AppLayout>
      <header className="flex items-end justify-between gap-3 flex-wrap mb-4">
        <div>
          <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Styling studio</div>
          <h1 className="font-display text-3xl md:text-4xl mt-1">{model.name}</h1>
          {sessionLookId && <div className="text-xs text-primary mt-1">Editing saved look · changes save as a new look</div>}
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {models.length > 1 && (
            <select value={model.id} onChange={(e) => setPickedId(e.target.value)} className="glass rounded-full px-3 py-1.5 text-sm bg-background/60">
              {models.map((m: Model) => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
          )}
        </div>
      </header>

      {/* Preview */}
      <div className="relative glass rounded-3xl overflow-hidden">
        <div className="aspect-[3/4] bg-dreamy">
          <img src={sessionImage || model.baseImageUrl} alt={model.name} className="h-full w-full object-cover" />
        </div>
        {busy && (
          <div className="absolute inset-0 grid place-items-center bg-background/40 backdrop-blur-sm">
            <div className="flex flex-col items-center gap-2 text-primary">
              <Loader2 className="h-8 w-8 animate-spin" />
              <div className="text-sm">AI is restyling…</div>
            </div>
          </div>
        )}
        <div className="absolute top-3 right-3 flex gap-2">
          <Button aria-label="Undo last styling change" size="sm" variant="secondary" disabled={busy || sessionHistory.length === 0} onClick={undo}><Undo2 className="h-3.5 w-3.5" /></Button>
          <Button aria-label="Reset to bare model template" size="sm" variant="secondary" disabled={busy} onClick={() => { if (confirm("Reset to bare model template?")) resetSession(); }}><RotateCcw className="h-3.5 w-3.5" /></Button>
          <Button aria-label="Save current look" size="sm" variant="secondary" disabled={busy} onClick={save}><Save className="h-3.5 w-3.5" /></Button>
        </div>
      </div>

      {/* Generation history */}
      {sessionHistory.length > 0 && (
        <section className="mt-4 glass rounded-2xl p-3">
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">History — click to revert</div>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {sessionHistory.map((url, i) => (
              <button key={i} onClick={() => revertTo(i)} disabled={busy}
                className="shrink-0 h-16 w-12 rounded-md overflow-hidden glass hover:shadow-glow transition disabled:opacity-50"
                aria-label={`Revert to styling step ${i + 1}`}
                title={`Revert to step ${i + 1}`}>
                <img src={url} alt={`Styling step ${i + 1} of ${model.name}`} className="h-full w-full object-cover" />
              </button>
            ))}
            <div className="shrink-0 h-16 w-12 rounded-md overflow-hidden ring-2 ring-primary">
              <img src={sessionImage} alt={`Current styling of ${model.name}`} className="h-full w-full object-cover" />
            </div>
          </div>
        </section>
      )}

      {/* Active styling tray */}
      <section className="mt-5 glass rounded-2xl p-4">
        <div className="flex items-center justify-between mb-2 gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <Shirt className="h-4 w-4 text-primary" />
            <h2 className="font-display text-lg">Active styling tray</h2>
            <span className="text-xs text-muted-foreground">({trayItems.length})</span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant={multiSelect ? "default" : "outline"}
              onClick={() => { setMultiSelect((v) => !v); setSelectedTrayIds([]); }}
              className={multiSelect ? "bg-glow text-primary-foreground shadow-glow" : ""}>
              <Layers className="h-3.5 w-3.5 mr-1" /> {multiSelect ? "Multi-select on" : "Multi-select"}
            </Button>
            {multiSelect && (
              <Button size="sm" disabled={busy || selectedTrayIds.length === 0}
                onClick={styleAllSelected} className="bg-glow text-primary-foreground shadow-glow">
                <Sparkles className="h-3.5 w-3.5 mr-1" /> Style Me ({selectedTrayIds.length})
              </Button>
            )}
            <Button size="sm" variant="outline" disabled={busy || trayItems.length === 0} onClick={clearTray}>
              <Trash className="h-3.5 w-3.5 mr-1" /> Hang Up Clothes
            </Button>
          </div>
        </div>
        {trayItems.length === 0 ? (
          <div className="text-xs text-muted-foreground">
            Click items in your closet to send them here. Then click a tray item to try it on one-at-a-time, or toggle <b>Multi-select</b> to style a full outfit in one go. Press × to send an item back to the closet.
          </div>
        ) : (
          <div className="flex gap-2 flex-wrap">
            {trayItems.map((it) => {
              const selected = selectedTrayIds.includes(it.id);
              return (
              <div key={it.id} className={cn("flex items-center gap-1 glass rounded-full pl-1 pr-1 py-1 hover:shadow-glow transition group", multiSelect && selected && "ring-2 ring-primary")}>
                <button onClick={() => multiSelect ? toggleTraySelection(it.id) : applyOne(it)} disabled={busy}
                  className="flex items-center gap-2 pr-2 disabled:opacity-50"
                  title={multiSelect ? (selected ? "Deselect" : "Select for full-outfit styling") : "Apply to model"}>
                  <div className="h-7 w-7 rounded-full overflow-hidden bg-dreamy"><img src={it.imageUrl} alt={it.name} className="h-full w-full object-cover" /></div>
                  <span className="text-xs">{it.name}</span>
                  {multiSelect && selected && <Check className="h-3 w-3 text-primary" />}
                </button>
                <button onClick={() => removeFromTray(it.id)} disabled={busy}
                  className="h-5 w-5 grid place-items-center rounded-full hover:bg-accent disabled:opacity-50"
                  aria-label={`Send ${it.name} back to closet`}
                  title="Send back to closet">
                  <X className="h-3 w-3" />
                </button>
              </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Closet strip */}
      <section className="mt-5">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-display text-lg">Your closet</h2>
          <Link to="/closet" className="text-xs underline text-muted-foreground">Manage</Link>
        </div>
        {closetItems.length === 0 ? (
          <div className="glass rounded-2xl p-6 text-center text-sm text-muted-foreground">
            Add clothing in your closet to dress this model. <Link to="/closet" className="underline">Open closet</Link>
          </div>
        ) : closetStripItems.length === 0 ? (
          <div className="glass rounded-2xl p-6 text-center text-sm text-muted-foreground">
            All items are in the tray. Hang some back up to see them here.
          </div>
        ) : (
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1 scrollbar-thin">
            {closetStripItems.map((it: ClosetItem) => {
              const worn = sessionWornIds.includes(it.id);
              return (
                <button key={it.id} disabled={busy} onClick={() => sendToTray(it)}
                  className={cn("group shrink-0 w-24 text-left rounded-xl glass overflow-hidden hover:shadow-glow transition", busy && "opacity-50")}>
                  <div className="aspect-square bg-dreamy relative">
                    <img src={it.imageUrl} className="h-full w-full object-cover" alt={it.name} />
                    {worn && <div className="absolute top-1 right-1 h-5 w-5 grid place-items-center rounded-full bg-glow text-primary-foreground"><Check className="h-3 w-3" /></div>}
                  </div>
                  <div className="px-2 py-1.5">
                    <div className="text-[11px] truncate font-medium">{it.name}</div>
                    <div className="text-[10px] text-muted-foreground truncate">{it.category}</div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </section>

      {/* Pose tweaks */}
      <section className="mt-5 glass rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <h2 className="font-display text-lg">{model.isInfant ? "Baby pose" : "Model pose"}</h2>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {(model.isInfant ? INFANT_POSE_CHIPS : POSE_CHIPS).map((p) => (
            <button key={p} disabled={busy} onClick={() => applyPose(p)} className="text-xs px-3 py-1.5 rounded-full glass hover:bg-accent disabled:opacity-50">{p}</button>
          ))}
        </div>
      </section>

      {/* AI styling prompt */}
      <section className="mt-5 glass rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-2"><Sparkles className="h-4 w-4 text-primary" /><h2 className="font-display text-lg">AI styling tweak</h2></div>
        <div className="flex gap-2">
          <Input value={styleInput} onChange={(e) => setStyleInput(e.target.value)} placeholder='"let the open shirt hang off the shoulders"'
            onKeyDown={(e) => { if (e.key === "Enter") restyle(styleInput); }} disabled={busy} />
          <Button onClick={() => restyle(styleInput)} disabled={busy || !styleInput.trim()} className="bg-glow text-primary-foreground shadow-glow">Apply</Button>
        </div>
        <div className="mt-2 flex flex-wrap gap-1">
          {STYLE_CHIPS.map((c) => (
            <button key={c} onClick={() => setStyleInput(c)} className="text-[10px] px-2 py-1 rounded-full glass hover:bg-accent">{c}</button>
          ))}
        </div>
      </section>
    </AppLayout>
  );
}
