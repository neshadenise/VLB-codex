
revoke execute on function public.has_role(uuid, public.app_role) from public, anon, authenticated;
revoke execute on function public.consume_credit_smart(uuid, integer) from public, anon, authenticated;
revoke execute on function public.consume_credit(uuid, integer) from public, anon, authenticated;
