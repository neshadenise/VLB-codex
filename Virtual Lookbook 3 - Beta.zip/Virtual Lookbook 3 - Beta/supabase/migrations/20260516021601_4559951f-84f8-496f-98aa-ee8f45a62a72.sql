create or replace function public.apply_credit_purchase(_session_id text, _payment_intent text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  p record;
begin
  select * into p from public.credit_purchases
    where stripe_session_id = _session_id for update;
  if not found then
    raise exception 'PURCHASE_NOT_FOUND';
  end if;
  if p.status = 'completed' then
    return;
  end if;

  update public.user_credits
    set balance = balance + p.credits, updated_at = now()
    where user_id = p.user_id;

  if not found then
    insert into public.user_credits (user_id, balance, generations_used, tier)
    values (p.user_id, p.credits, 0, 'free');
  end if;

  update public.credit_purchases
    set status = 'completed',
        stripe_payment_intent = coalesce(nullif(_payment_intent, ''), stripe_payment_intent),
        updated_at = now()
    where id = p.id;
end;
$$;
revoke execute on function public.apply_credit_purchase(text, text) from public, anon, authenticated;