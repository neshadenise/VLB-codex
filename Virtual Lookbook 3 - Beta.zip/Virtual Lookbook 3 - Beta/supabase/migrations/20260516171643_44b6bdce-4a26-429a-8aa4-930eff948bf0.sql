
-- Seed neshadenise as master_admin in user_roles
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'master_admin'::public.app_role
FROM auth.users
WHERE lower(email) = 'neshadenise@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;

-- Update is_master_admin: prefer DB role; fall back to hardcoded email only if no master_admin exists yet (bootstrap safety)
CREATE OR REPLACE FUNCTION public.is_master_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = 'master_admin')
    OR (
      NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'master_admin')
      AND EXISTS (SELECT 1 FROM auth.users WHERE id = _user_id AND lower(email) = 'neshadenise@gmail.com')
    );
$$;

-- Update handle_new_user to also seed master_admin for the bootstrap email
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
begin
  insert into public.profiles (user_id, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict do nothing;

  insert into public.user_credits (user_id, balance, generations_used, tier)
  values (new.id, 25, 0, 'free')
  on conflict (user_id) do nothing;

  insert into public.user_roles (user_id, role)
  values (new.id, 'user')
  on conflict (user_id, role) do nothing;

  if lower(new.email) = 'neshadenise@gmail.com' then
    insert into public.user_roles (user_id, role) values (new.id, 'admin')
    on conflict (user_id, role) do nothing;
    -- Seed master_admin only if none exists
    if not exists (select 1 from public.user_roles where role = 'master_admin') then
      insert into public.user_roles (user_id, role) values (new.id, 'master_admin')
      on conflict (user_id, role) do nothing;
    end if;
  end if;

  return new;
end;
$$;

-- =========================================================
-- Tables
-- =========================================================

CREATE TABLE IF NOT EXISTS public.master_admin_settings (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  recovery_email text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.master_admin_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY mas_select_master ON public.master_admin_settings
  FOR SELECT USING (public.is_master_admin(auth.uid()));
-- Writes only via SECURITY DEFINER RPCs (no INSERT/UPDATE/DELETE policies)

CREATE TABLE IF NOT EXISTS public.master_admin_recovery_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  code_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  used_at timestamptz,
  revoked_at timestamptz
);
CREATE INDEX IF NOT EXISTS marc_user_idx ON public.master_admin_recovery_codes(user_id);
CREATE INDEX IF NOT EXISTS marc_hash_idx ON public.master_admin_recovery_codes(code_hash);
ALTER TABLE public.master_admin_recovery_codes ENABLE ROW LEVEL SECURITY;
-- No policies: access only via SECURITY DEFINER RPCs (codes never exposed)

CREATE TABLE IF NOT EXISTS public.admin_security_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id uuid,
  actor_email text,
  action text NOT NULL,
  target_email text,
  success boolean NOT NULL DEFAULT true,
  ip text,
  user_agent text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ase_created_idx ON public.admin_security_events(created_at DESC);
ALTER TABLE public.admin_security_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY ase_select_admin ON public.admin_security_events
  FOR SELECT USING (public.has_role(auth.uid(), 'admin') OR public.is_master_admin(auth.uid()));

-- =========================================================
-- Helper: log event (SECURITY DEFINER, callable from other RPCs)
-- =========================================================
CREATE OR REPLACE FUNCTION public.log_admin_event(
  _action text,
  _target_email text DEFAULT NULL,
  _success boolean DEFAULT true,
  _ip text DEFAULT NULL,
  _user_agent text DEFAULT NULL,
  _metadata jsonb DEFAULT '{}'::jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  uemail text;
BEGIN
  IF uid IS NOT NULL THEN
    SELECT email::text INTO uemail FROM auth.users WHERE id = uid;
  END IF;
  INSERT INTO public.admin_security_events
    (actor_user_id, actor_email, action, target_email, success, ip, user_agent, metadata)
  VALUES (uid, uemail, _action, _target_email, _success, _ip, _user_agent, coalesce(_metadata, '{}'::jsonb));
END;
$$;

-- =========================================================
-- Recovery email
-- =========================================================
CREATE OR REPLACE FUNCTION public.set_master_recovery_email(_email text, _ip text DEFAULT NULL, _ua text DEFAULT NULL)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  clean text := lower(trim(_email));
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF NOT public.is_master_admin(uid) THEN RAISE EXCEPTION 'NOT_MASTER_ADMIN'; END IF;
  IF clean !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' THEN RAISE EXCEPTION 'INVALID_EMAIL'; END IF;

  INSERT INTO public.master_admin_settings (user_id, recovery_email, updated_at)
  VALUES (uid, clean, now())
  ON CONFLICT (user_id) DO UPDATE SET recovery_email = EXCLUDED.recovery_email, updated_at = now();

  PERFORM public.log_admin_event('recovery_email_changed', clean, true, _ip, _ua, '{}'::jsonb);
  RETURN clean;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_master_recovery_email()
RETURNS text
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  e text;
BEGIN
  IF uid IS NULL OR NOT public.is_master_admin(uid) THEN RETURN NULL; END IF;
  SELECT recovery_email INTO e FROM public.master_admin_settings WHERE user_id = uid;
  RETURN e;
END;
$$;

-- =========================================================
-- Recovery codes (server hashes; we store the hash)
-- =========================================================
CREATE OR REPLACE FUNCTION public.register_master_recovery_codes(_hashes text[], _ip text DEFAULT NULL, _ua text DEFAULT NULL)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  h text;
  n integer := 0;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF NOT public.is_master_admin(uid) THEN RAISE EXCEPTION 'NOT_MASTER_ADMIN'; END IF;

  -- Revoke existing unused codes when regenerating
  UPDATE public.master_admin_recovery_codes
     SET revoked_at = now()
   WHERE user_id = uid AND used_at IS NULL AND revoked_at IS NULL;

  FOREACH h IN ARRAY _hashes LOOP
    IF h IS NOT NULL AND length(h) >= 32 THEN
      INSERT INTO public.master_admin_recovery_codes (user_id, code_hash) VALUES (uid, h);
      n := n + 1;
    END IF;
  END LOOP;

  PERFORM public.log_admin_event('recovery_codes_generated', NULL, true, _ip, _ua,
    jsonb_build_object('count', n));
  RETURN n;
END;
$$;

CREATE OR REPLACE FUNCTION public.revoke_master_recovery_codes(_ip text DEFAULT NULL, _ua text DEFAULT NULL)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  n integer;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF NOT public.is_master_admin(uid) THEN RAISE EXCEPTION 'NOT_MASTER_ADMIN'; END IF;
  UPDATE public.master_admin_recovery_codes
     SET revoked_at = now()
   WHERE user_id = uid AND used_at IS NULL AND revoked_at IS NULL;
  GET DIAGNOSTICS n = ROW_COUNT;
  PERFORM public.log_admin_event('recovery_codes_revoked', NULL, true, _ip, _ua,
    jsonb_build_object('count', n));
  RETURN n;
END;
$$;

CREATE OR REPLACE FUNCTION public.list_master_recovery_codes_meta()
RETURNS TABLE(total integer, active integer, used integer, last_generated timestamptz)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE uid uuid := auth.uid();
BEGIN
  IF uid IS NULL OR NOT public.is_master_admin(uid) THEN
    total := 0; active := 0; used := 0; last_generated := NULL; RETURN NEXT; RETURN;
  END IF;
  SELECT
    count(*)::int,
    count(*) FILTER (WHERE used_at IS NULL AND revoked_at IS NULL)::int,
    count(*) FILTER (WHERE used_at IS NOT NULL)::int,
    max(created_at)
  INTO total, active, used, last_generated
  FROM public.master_admin_recovery_codes
  WHERE user_id = uid;
  RETURN NEXT;
END;
$$;

-- =========================================================
-- Transfer master admin (manual, while logged in as current master)
-- =========================================================
CREATE OR REPLACE FUNCTION public.transfer_master_admin(
  _target_email text,
  _confirm_phrase text,
  _keep_old_as_admin boolean DEFAULT true,
  _ip text DEFAULT NULL,
  _ua text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  target uuid;
  clean text := lower(trim(_target_email));
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF NOT public.is_master_admin(uid) THEN
    PERFORM public.log_admin_event('master_transfer_attempt', clean, false, _ip, _ua, '{}'::jsonb);
    RAISE EXCEPTION 'NOT_MASTER_ADMIN';
  END IF;
  IF _confirm_phrase IS DISTINCT FROM 'TRANSFER MASTER ADMIN' THEN
    PERFORM public.log_admin_event('master_transfer_attempt', clean, false, _ip, _ua,
      jsonb_build_object('reason','bad_phrase'));
    RAISE EXCEPTION 'BAD_CONFIRMATION';
  END IF;

  SELECT id INTO target FROM auth.users WHERE lower(email) = clean LIMIT 1;
  IF target IS NULL THEN RAISE EXCEPTION 'USER_NOT_FOUND'; END IF;
  IF target = uid THEN RAISE EXCEPTION 'CANNOT_TRANSFER_TO_SELF'; END IF;

  -- Grant master_admin + admin to target
  INSERT INTO public.user_roles (user_id, role) VALUES (target, 'master_admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (target, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;

  -- Remove master from current
  DELETE FROM public.user_roles WHERE user_id = uid AND role = 'master_admin';
  IF NOT _keep_old_as_admin THEN
    DELETE FROM public.user_roles WHERE user_id = uid AND role = 'admin';
  END IF;

  -- Revoke recovery codes (new master should generate fresh)
  UPDATE public.master_admin_recovery_codes
    SET revoked_at = now()
    WHERE user_id = uid AND used_at IS NULL AND revoked_at IS NULL;

  PERFORM public.log_admin_event('master_transferred', clean, true, _ip, _ua,
    jsonb_build_object('keep_old_as_admin', _keep_old_as_admin));
  RETURN target;
END;
$$;

-- =========================================================
-- Emergency recovery: consume a code + recovery email + target email
-- (callable by anyone — server route validates)
-- =========================================================
CREATE OR REPLACE FUNCTION public.consume_master_recovery_code(
  _code_hash text,
  _recovery_email text,
  _new_master_email text,
  _ip text DEFAULT NULL,
  _ua text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  rec record;
  stored_recovery text;
  target uuid;
  clean_rec text := lower(trim(_recovery_email));
  clean_new text := lower(trim(_new_master_email));
BEGIN
  -- Find matching unused, unrevoked code
  SELECT * INTO rec FROM public.master_admin_recovery_codes
   WHERE code_hash = _code_hash AND used_at IS NULL AND revoked_at IS NULL
   LIMIT 1;
  IF NOT FOUND THEN
    INSERT INTO public.admin_security_events (action, target_email, success, ip, user_agent, metadata)
    VALUES ('recovery_attempt', clean_new, false, _ip, _ua, jsonb_build_object('reason','bad_code'));
    RAISE EXCEPTION 'INVALID_CODE';
  END IF;

  -- Verify recovery email matches stored
  SELECT recovery_email INTO stored_recovery FROM public.master_admin_settings WHERE user_id = rec.user_id;
  IF stored_recovery IS NULL OR stored_recovery <> clean_rec THEN
    INSERT INTO public.admin_security_events (action, target_email, success, ip, user_agent, metadata)
    VALUES ('recovery_attempt', clean_new, false, _ip, _ua, jsonb_build_object('reason','bad_recovery_email'));
    RAISE EXCEPTION 'INVALID_RECOVERY_EMAIL';
  END IF;

  -- Find new master user (must already have signed up)
  SELECT id INTO target FROM auth.users WHERE lower(email) = clean_new LIMIT 1;
  IF target IS NULL THEN
    INSERT INTO public.admin_security_events (action, target_email, success, ip, user_agent, metadata)
    VALUES ('recovery_attempt', clean_new, false, _ip, _ua, jsonb_build_object('reason','new_user_missing'));
    RAISE EXCEPTION 'USER_NOT_FOUND';
  END IF;

  -- Mark code used; revoke all others for this master
  UPDATE public.master_admin_recovery_codes SET used_at = now() WHERE id = rec.id;
  UPDATE public.master_admin_recovery_codes
    SET revoked_at = now()
    WHERE user_id = rec.user_id AND used_at IS NULL AND revoked_at IS NULL;

  -- Transfer master role to target
  INSERT INTO public.user_roles (user_id, role) VALUES (target, 'master_admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (target, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  DELETE FROM public.user_roles WHERE user_id = rec.user_id AND role = 'master_admin';

  INSERT INTO public.admin_security_events (actor_user_id, action, target_email, success, ip, user_agent, metadata)
  VALUES (target, 'master_recovered', clean_new, true, _ip, _ua,
    jsonb_build_object('previous_master_user_id', rec.user_id));

  RETURN target;
END;
$$;

-- =========================================================
-- Security event listing
-- =========================================================
CREATE OR REPLACE FUNCTION public.list_admin_security_events(_limit integer DEFAULT 50)
RETURNS TABLE(
  id uuid, actor_email text, action text, target_email text,
  success boolean, ip text, user_agent text, metadata jsonb, created_at timestamptz
)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT (public.has_role(auth.uid(), 'admin') OR public.is_master_admin(auth.uid())) THEN
    RAISE EXCEPTION 'NOT_ADMIN';
  END IF;
  RETURN QUERY
    SELECT e.id, e.actor_email, e.action, e.target_email, e.success, e.ip, e.user_agent, e.metadata, e.created_at
    FROM public.admin_security_events e
    ORDER BY e.created_at DESC
    LIMIT GREATEST(1, LEAST(_limit, 500));
END;
$$;
