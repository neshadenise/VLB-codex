
-- Master admin enforcement: only neshadenise@gmail.com may grant/revoke admin.

CREATE OR REPLACE FUNCTION public.is_master_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM auth.users
    WHERE id = _user_id AND lower(email) = 'neshadenise@gmail.com'
  );
$$;

CREATE OR REPLACE FUNCTION public.grant_admin_by_email(_email text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  caller uuid := auth.uid();
  target uuid;
BEGIN
  IF caller IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF NOT public.is_master_admin(caller) THEN RAISE EXCEPTION 'NOT_MASTER_ADMIN'; END IF;

  SELECT id INTO target FROM auth.users WHERE lower(email) = lower(trim(_email)) LIMIT 1;
  IF target IS NULL THEN RAISE EXCEPTION 'USER_NOT_FOUND'; END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (target, 'admin')
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN target;
END;
$$;

CREATE OR REPLACE FUNCTION public.revoke_admin_by_email(_email text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  caller uuid := auth.uid();
  target uuid;
  target_email text;
BEGIN
  IF caller IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF NOT public.is_master_admin(caller) THEN RAISE EXCEPTION 'NOT_MASTER_ADMIN'; END IF;

  SELECT id, lower(email) INTO target, target_email FROM auth.users
   WHERE lower(email) = lower(trim(_email)) LIMIT 1;
  IF target IS NULL THEN RAISE EXCEPTION 'USER_NOT_FOUND'; END IF;

  IF target_email = 'neshadenise@gmail.com' THEN
    RAISE EXCEPTION 'CANNOT_REVOKE_MASTER';
  END IF;

  DELETE FROM public.user_roles WHERE user_id = target AND role = 'admin';
  RETURN target;
END;
$$;

CREATE OR REPLACE FUNCTION public.am_i_master_admin()
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT auth.uid() IS NOT NULL AND public.is_master_admin(auth.uid());
$$;
