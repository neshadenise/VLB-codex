CREATE TABLE IF NOT EXISTS public.credit_packs (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  tagline TEXT,
  badge TEXT,
  credits INTEGER NOT NULL CHECK (credits > 0),
  bonus_credits INTEGER NOT NULL DEFAULT 0 CHECK (bonus_credits >= 0),
  price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
  currency TEXT NOT NULL DEFAULT 'usd',
  icon TEXT NOT NULL DEFAULT 'sparkles',
  theme TEXT NOT NULL DEFAULT 'pastel',
  highlight BOOLEAN NOT NULL DEFAULT false,
  active BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS credit_packs_sort_idx ON public.credit_packs (sort_order, id);

ALTER TABLE public.credit_packs ENABLE ROW LEVEL SECURITY;

-- Anyone (including anon) can see active packs; master admin sees everything
CREATE POLICY "credit_packs_select_active_or_master"
  ON public.credit_packs FOR SELECT
  USING (active = true OR public.is_master_admin(auth.uid()));

CREATE POLICY "credit_packs_master_insert"
  ON public.credit_packs FOR INSERT
  WITH CHECK (public.is_master_admin(auth.uid()));

CREATE POLICY "credit_packs_master_update"
  ON public.credit_packs FOR UPDATE
  USING (public.is_master_admin(auth.uid()))
  WITH CHECK (public.is_master_admin(auth.uid()));

CREATE POLICY "credit_packs_master_delete"
  ON public.credit_packs FOR DELETE
  USING (public.is_master_admin(auth.uid()));

CREATE TRIGGER credit_packs_set_updated_at
  BEFORE UPDATE ON public.credit_packs
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Seed defaults (only if table empty)
INSERT INTO public.credit_packs (id, name, tagline, credits, price_cents, icon, theme, highlight, sort_order)
SELECT * FROM (VALUES
  ('mini',    'Mini Pack',    'Quick top-up',   50,   499, 'sparkles', 'pastel', false, 10),
  ('creator', 'Creator Pack', 'Most popular',   150,  999, 'wand',     'astro',  true,  20),
  ('studio',  'Studio Pack',  'Best value',     400, 1999, 'gem',      'ocean',  false, 30),
  ('muse',    'Muse Pack',    'Power creator', 1200, 4999, 'crown',    'flame',  false, 40)
) AS v(id, name, tagline, credits, price_cents, icon, theme, highlight, sort_order)
WHERE NOT EXISTS (SELECT 1 FROM public.credit_packs);