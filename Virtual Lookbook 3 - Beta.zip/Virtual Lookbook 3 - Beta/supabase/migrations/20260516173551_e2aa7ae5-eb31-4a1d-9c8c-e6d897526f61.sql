-- 1) Drop overly permissive storage policies on studio-images
DROP POLICY IF EXISTS "Anyone can delete studio-images" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can update studio-images" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can upload studio-images" ON storage.objects;
-- Also drop the duplicate broad public-read; keep one canonical SELECT.
DROP POLICY IF EXISTS "Public read studio-images" ON storage.objects;

-- 2) user_roles: explicit restrictive rules so only master_admin can write
CREATE POLICY user_roles_master_insert
  ON public.user_roles FOR INSERT TO authenticated
  WITH CHECK (public.is_master_admin(auth.uid()));
CREATE POLICY user_roles_master_update
  ON public.user_roles FOR UPDATE TO authenticated
  USING (public.is_master_admin(auth.uid()))
  WITH CHECK (public.is_master_admin(auth.uid()));
CREATE POLICY user_roles_master_delete
  ON public.user_roles FOR DELETE TO authenticated
  USING (public.is_master_admin(auth.uid()));

-- 3) admin_security_events: block all writes from the API
CREATE POLICY ase_no_insert ON public.admin_security_events
  FOR INSERT TO authenticated, anon WITH CHECK (false);
CREATE POLICY ase_no_update ON public.admin_security_events
  FOR UPDATE TO authenticated, anon USING (false) WITH CHECK (false);
CREATE POLICY ase_no_delete ON public.admin_security_events
  FOR DELETE TO authenticated, anon USING (false);

-- 4) master_admin_recovery_codes: explicit deny-all on API (writes only via SECURITY DEFINER RPCs)
CREATE POLICY marc_no_select ON public.master_admin_recovery_codes
  FOR SELECT TO authenticated, anon USING (false);
CREATE POLICY marc_no_insert ON public.master_admin_recovery_codes
  FOR INSERT TO authenticated, anon WITH CHECK (false);
CREATE POLICY marc_no_update ON public.master_admin_recovery_codes
  FOR UPDATE TO authenticated, anon USING (false) WITH CHECK (false);
CREATE POLICY marc_no_delete ON public.master_admin_recovery_codes
  FOR DELETE TO authenticated, anon USING (false);

-- 5) Revoke EXECUTE on internal helper SECURITY DEFINER functions from anon/authenticated.
--    These are used internally by RLS / other SECURITY DEFINER functions and should
--    not be callable directly over PostgREST.
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_master_admin(uuid) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.log_admin_event(text, text, boolean, text, text, jsonb) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.consume_credit(uuid, integer) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.consume_credit_smart(uuid, integer) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.apply_credit_purchase(text, text) FROM anon, authenticated;
-- Public recovery RPC must remain callable by anon (the public /api/public/master-recovery endpoint
-- calls it via the service role anyway, so revoke from API roles too):
REVOKE EXECUTE ON FUNCTION public.consume_master_recovery_code(text, text, text, text, text) FROM anon, authenticated;