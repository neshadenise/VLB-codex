
create table if not exists public.credit_purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  pack_id text not null,
  credits integer not null,
  amount_cents integer not null,
  currency text not null default 'usd',
  status text not null default 'pending',
  stripe_session_id text unique,
  stripe_payment_intent text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.credit_purchases enable row level security;

create policy "purchases_select_own" on public.credit_purchases
  for select using (auth.uid() = user_id);

create index if not exists idx_credit_purchases_user on public.credit_purchases(user_id);
create index if not exists idx_credit_purchases_session on public.credit_purchases(stripe_session_id);

create or replace function public.apply_credit_purchase(_session_id text, _payment_intent text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  p record;
begin
  select * into p from public.credit_purchases
    where stripe_session_id = _session_id for update;
  if not found then
    raise exception 'PURCHASE_NOT_FOUND';
  end if;
  if p.status = 'completed' then
    return;
  end if;

  update public.user_credits
    set balance = balance + p.credits, updated_at = now()
    where user_id = p.user_id;

  if not found then
    insert into public.user_credits (user_id, balance, generations_used, tier)
    values (p.user_id, p.credits, 0, 'free');
  end if;

  update public.credit_purchases
    set status = 'completed',
        stripe_payment_intent = coalesce(_payment_intent, stripe_payment_intent),
        updated_at = now()
    where id = p.id;
end;
$$;
