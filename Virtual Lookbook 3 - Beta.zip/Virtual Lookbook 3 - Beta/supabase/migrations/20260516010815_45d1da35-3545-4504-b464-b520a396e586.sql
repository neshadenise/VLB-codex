
-- Role enum
do $$ begin
  create type public.app_role as enum ('user', 'admin');
exception when duplicate_object then null; end $$;

-- user_roles table
create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null default 'user',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, role)
);

alter table public.user_roles enable row level security;

drop policy if exists "user_roles_select_own" on public.user_roles;
create policy "user_roles_select_own" on public.user_roles
  for select to authenticated
  using (auth.uid() = user_id);

-- No insert/update/delete policies → only service role (server-side) can modify.

-- Updated-at trigger
drop trigger if exists set_user_roles_updated_at on public.user_roles;
create trigger set_user_roles_updated_at
  before update on public.user_roles
  for each row execute function public.set_updated_at();

-- Secure role check
create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _user_id and role = _role
  );
$$;

-- Admin-aware credit consumption: bypasses for admins, otherwise atomic deduct
create or replace function public.consume_credit_smart(_user_id uuid, _cost integer default 1)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  new_balance integer;
begin
  if public.has_role(_user_id, 'admin') then
    -- Track usage but never deduct, never block.
    update public.user_credits
       set generations_used = generations_used + 1,
           updated_at = now()
     where user_id = _user_id
    returning balance into new_balance;
    if new_balance is null then
      insert into public.user_credits (user_id, balance, generations_used, tier)
      values (_user_id, 999999, 1, 'admin')
      returning balance into new_balance;
    end if;
    return new_balance;
  end if;

  update public.user_credits
     set balance = balance - _cost,
         generations_used = generations_used + 1,
         updated_at = now()
   where user_id = _user_id and balance >= _cost
  returning balance into new_balance;
  if new_balance is null then
    raise exception 'INSUFFICIENT_CREDITS';
  end if;
  return new_balance;
end;
$$;

-- Patch new-user trigger to auto-grant admin to designated email
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (user_id, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict do nothing;

  insert into public.user_credits (user_id, balance, generations_used, tier)
  values (new.id, 25, 0, 'free')
  on conflict (user_id) do nothing;

  -- Always seed user role
  insert into public.user_roles (user_id, role)
  values (new.id, 'user')
  on conflict (user_id, role) do nothing;

  -- Admin allow-list
  if lower(new.email) = 'neshadenise@gmail.com' then
    insert into public.user_roles (user_id, role)
    values (new.id, 'admin')
    on conflict (user_id, role) do nothing;
  end if;

  return new;
end;
$$;

-- Ensure trigger exists on auth.users
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Backfill: grant admin role to existing matching user, and a baseline user role to everyone.
insert into public.user_roles (user_id, role)
select id, 'user'::public.app_role from auth.users
on conflict (user_id, role) do nothing;

insert into public.user_roles (user_id, role)
select id, 'admin'::public.app_role from auth.users
where lower(email) = 'neshadenise@gmail.com'
on conflict (user_id, role) do nothing;
